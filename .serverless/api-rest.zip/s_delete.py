import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='maxigg10',
    application_name='todo-list-serverless',
    app_uid='dbCG0TqyvdgY06gvYG',
    org_uid='47979b05-1868-44fd-a9e2-8985068f28cf',
    deployment_uid='cd41d241-ece0-4e9a-bc79-12de69de8df9',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
